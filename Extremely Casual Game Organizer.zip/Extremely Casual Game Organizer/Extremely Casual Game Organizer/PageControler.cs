﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Extremely_Casual_Game_Organizer
{
    class PageControler
    {
        MainWindow _mainWindow = null;

        public PageControler()
        {
            _mainWindow = (MainWindow)Application.Current.MainWindow;
        }


    }
}
