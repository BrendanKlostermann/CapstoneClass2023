﻿/// <ILeagueManager>
/// Alex Korte
/// Created: 2023/01/24
/// 
/// </summary>
/// This is an interface that helps control leauges
/// 
/// Updater Name
/// Updated: yyyy/mm/dd
/// </remarks>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;

namespace LogicLayerInterfaces
{
    public interface ILeagueManager
    {
        List<League> GetListOfLeagues();

        List<Team> GetAListOfTeamsByLeagueID(int leagueID);

        int RemoveATeamFromALeagueByTeamIDAndLeagueID(int teamId, int leagueID);
    }
}
